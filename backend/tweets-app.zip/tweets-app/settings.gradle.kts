rootProject.name = "tweets-app"
